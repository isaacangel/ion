let brokers: Array<any> = [
    {
        id: 1,
        name: "Juanita Perez",
        title: "Vendedor Maestro",
        phone: "4244441",
        mobilePhone: "70701231",
        email: "juanita.perez@aplicasapp.com",
        picture: "https://2.bp.blogspot.com/-DnwcQ4brIps/Wlt-tca7yWI/AAAAAAAAJKk/ortPsJ0kDIk0KxZh-MsCci_hdoJl5Ro2wCLcBGAs/s1600/20160711190355-marca-yo.jpeg"
    },
    {
        id: 2,
        name: "Juan Perez",
        title: "Vendedor Maestro",
        phone: "4244442",
        mobilePhone: "70701232",
        email: "juan.perez@aplicasapp.com",
        picture: "https://4.bp.blogspot.com/-QqtAjK0V-ZU/Wlt-uBnUTBI/AAAAAAAAJKo/i6sHIGM0L08ZusGXz55Xu4h42C8X_JaWQCLcBGAs/s1600/chris-gardner.jpg"
    },
    {
        id: 3,
        name: "Julia Lopez",
        title: "Vendedor Junior",
        phone: "4244443",
        mobilePhone: "70701233",
        email: "julia.lopez@aplicasapp.com",
        picture: "https://1.bp.blogspot.com/-LQpWCxosxps/Wlt-vsE-uMI/AAAAAAAAJKw/LvZQMS_aU4IJ8mcYiSUcmVaxz0Izj73LwCLcBGAs/s1600/diez%2Batributos%2Bde%2Bla%2Bpersonalidad%2Bde%2Bun%2Bvendedor%2Bexitoso.jpg"
    },
    {
        id: 4,
        name: "Maria Martinez",
        title: "Vendedor Maestro",
        phone: "4244444",
        mobilePhone: "70701234",
        email: "maria.martinez@aplicasapp.com",
        picture: "https://2.bp.blogspot.com/-kN9RWH9G924/Wlt-vS4QkqI/AAAAAAAAJKs/qZj7DWDrRTYrXeo6dkIyPEyBLbTHA46QQCLcBGAs/s1600/grupo-de-vendedores.jpg"
    },
    {
        id: 5,
        name: "Fernando Fernandez",
        title: "Vendedor Maestro",
        phone: "4244445",
        mobilePhone: "70701235",
        email: "fernando.fernandez@aplicasapp.com",
        picture: "https://3.bp.blogspot.com/-tsfaPH6KQzE/Wlt_E-CfXKI/AAAAAAAAJLM/0H3aQNNeBHQBj6ayIpvEkxBsEzGBQSaxACLcBGAs/s1600/happy-businessman.jpg"
    },
    {
        id: 6,
        name: "Mario Mendez",
        title: "Vendedor Junior",
        phone: "4244446",
        mobilePhone: "70701236",
        email: "mario.mendez@aplicasapp.com",
        picture: "https://1.bp.blogspot.com/-t0gvqFMGGs4/Wlt-wkNirKI/AAAAAAAAJK0/i66bi7M5-pYS7_4hqeNKp7tZU61Vx7YZACLcBGAs/s1600/how-to-spot-a-dodgy-car-salesman-1091106-TwoByOne.jpg"
    },
    {
        id: 7,
        name: "Laura Lima",
        title: "Vendedor Maestro",
        phone: "42444417",
        mobilePhone: "70701237",
        email: "laura.lima@aplicasapp.com",
        picture: "https://1.bp.blogspot.com/-xLtaGxx4edg/Wlt-4ybWYBI/AAAAAAAAJLI/Z50DwYf-INY7sW2O6seStQEqONbz0-3YQCLcBGAs/s1600/vendedores.jpg"
    },
    {
        id: 8,
        name: "Victor Suarez",
        title: "Vendedor Junior",
        phone: "42444418",
        mobilePhone: "70701238",
        email: "victor.suarez@aplicasapp.com",
        picture: "https://3.bp.blogspot.com/-a-brHnaF1Dk/Wlt-1pMFXHI/AAAAAAAAJLA/JWDwlte6mdsIoAfBnzPkE_FLP65ZokFgACLcBGAs/s1600/noticias_fotocabecera_11129.jpg"
    }
];

export default brokers;
