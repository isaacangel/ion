export class Location {

  public latitude: number;
  public longitude: number;

  constructor() {
  }
  
}