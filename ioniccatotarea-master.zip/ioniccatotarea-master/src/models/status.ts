import { Contact } from "./contact";

export class Status {

  text: String;
  image: String;
  date: Date;
  contact: Contact;
  
  constructor() {

  }
  
}