export class User {

  name: string;
  lastName: string;
  email: string;
  password: string;

  constructor() {
  }
  
}