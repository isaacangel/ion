export class Contact {

  name: String;
  constructor(name: String) {
      this.name = name;
  }
  
}