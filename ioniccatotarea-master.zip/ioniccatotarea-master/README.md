# ApliCASApp

Tarea Catolica Ionic 

## Instrucciones


1. **Ver que se tengan instaladas:**
    ```
    npm install -g cordova
    npm install -g ionic
    ```

2. Clonar el repositorio
    ```
    git clone https://github.com/isaacangel/ioniccatotarea.git
    ```

3. Ingresar al directorio de `ApliCASApp`
    ```
    cd ApliCASApp
    ```

4. Instalar dependencias
    ```
    npm install
    ```
  
5. Correr en el navegador
    ```
    ionic serve
    ```
